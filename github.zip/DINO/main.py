import pygame
import os



size_cloud = (84, 101)
cloude_size = (84, 101)
cactus_1_size = (40, 71)
cactus_1_size = (68, 71)
cactus_1_size = (105, 71)
size_track = (2404, 28)
size_scr = (500, 500)
size_hero = (88, 94)

EARTH = 400
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)


abs_path = os.path.join(os.path.abspath(__file__ + "/.."), "image")

cloud_image = pygame.image.load(os.path.join(abs_path, "Cloud.png"))
dino_image = [
pygame.image.load(os.path.join(abs_path, "/storage/emulated/0/dino/image/DinoJump.png")),
pygame.image.load(os.path.join(abs_path, "/storage/emulated/0/dino/image/DinoRun1.png")),
pygame.image.load(os.path.join(abs_path, "/storage/emulated/0/dino/image/DinoRun2.png"))
]
cactus_1_image = pygame.image.load(os.path.join(abs_path, "SmallCactus1.png"))
cactus_2_image = pygame.image.load(os.path.join(abs_path, "SmallCactus2.png"))
cactus_3_image = pygame.image.load(os.path.join(abs_path, "SmallCactus3.png"))
track_image = pygame.image.load(os.path.join(abs_path, "Track.png"))





EARTH = 400

pygame.init()

class Label(pygame.font.Font):
    def __init__(self, size, font, colors, text):
        super().__init__(font, size)
        self.colors = colors
        self.text = text
        self.d_text = self.render(text, True, colors[0])

    def blit_text(self, x, y, screen):
        screen.blit(self.d_text, (x, y))

class Button(pygame.Rect):
    def __init__(self, x, y, width, heigth, colors, label):
        super().__init__(x, y, width, heigth)
        self.colors = colors
        self.label = label
        self.index = 0
        self.select = False

    def draw(self, screen):
        pygame.draw.rect(screen, self.colors[self.index], self)
        self.label.blit_text(
            self.centerx - self.label.size(self.label.text)[0] // 2,
            self.centery - self.label.size(self.label.text)[1] //2,
            screen
        )
    def active(self, events):
        if self.collidepoint(pygame.mouse.get_pos()):
            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                        print(1)
                        self.index = 2
                        self.select = True
                        return True
                if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    self.index = 0
                    self.select = False

                if not self.select:
                    self.index = 1
        else:
                self.index = 0

        return False



class Sprite(pygame.Rect):
    def __init__(self, x, y, width, heigth, color):
        super().__init__(x, y, width, heigth)
        self.color = color

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self)

class Hero(Sprite):
    def __init__(self, x, y, width, heigth, color, image):
        super().__init__(x, y, width, heigth, color)
        self.image_list = image
        self.image = self.image_list[0]
        self.image_count = 9
        self.jump_select = False
        self.jump_power_static = 20
        self.jump_power = self.jump_power_static
        self.gravitation_power = 3

    def jump(self, events):
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w and self.jump_select:
                    self.jump_select = False
        if not self.jump_select:
            self.y -= self.jump_power
            self.jump_power -= 2
        else:
            self.jump_power = self.jump_power_static


    def gravitation(self):
        if self.bottom >= EARTH:
            self.bottom = EARTH
            self.jump_select = True
        else:
            self.y += self.gravitation_power

    def blit_hero(self, screen):
        screen.blit(self.image, (self.x, self.y))


    def move_image(self):
        if not self.jump_select:
            self.image = self.image_list[0]
        else:
            if self.image_count == 29:
                self.image_count = 9
            self.image_count += 1
            if self.image_count  % 10 == 0:
                self.image = self.image_list[self.image_count // 10]


class Background():
    def __init__(self, x, y, width, speed, image):
        self.x1 = x
        self.x2 = self.x1 + width
        self.y = y
        self.width = width
        self.speed = speed
        self.image1 = image
        self.image2 = image

    def move(self):
        self.x1 -= self.speed
        self.x2 -= self.speed
        if self.x1 < -self.width:
            self.x1 = -self.width
        if self.x2 < -self.width:
            self.x2 = -self.width

    def blit_bg(self, screen):
        screen.blit(self.image1, (self.x1, self.y))
        screen.blit(self.image2, (self.x2, self.y))


screen = pygame.display.set_mode(size_scr)
clock = pygame.time.Clock()

game = True

size_button = (150, 50)

play_label = Label(40, None, ((0, 0, 0), (157, 255, 122), (122, 255, 231)), "START")
exit_label = Label(40, None, ((0, 0, 0), (157, 255, 122), (122, 255, 231)), "EXIT")
button = Button(
    size_scr[0] // 2 - size_button[0] // 2, # - x
    size_scr[1] // 2 - size_button[1] // 2 - 40, # - y
    size_button[0],
    size_button[1],
    ((0, 255, 0, ), (0, 255, 255), (255, 255, 0)),
    play_label
)
play = Button(
    size_scr[0] // 2 - size_button[0] // 2,
    size_scr[1] // 2 - size_button[1] // 2 - 40, 
    size_button[0],
    size_button[1],
    ((24, 210, 134), (24, 180, 96), (238, 154, 10)),
    play_label
)

exit = Button(
    size_scr[0] // 2 - size_button[0] // 2,
    size_scr[1] // 2 - size_button[1] // 2,
    size_button[0],
    size_button[1],
    ((0, 255, 0, ), (0, 255, 255), (255, 255, 0)),
    exit_label
)
hero = Hero(30, EARTH - size_hero[1] -  40, size_hero[0], size_hero[1], "#ff2f2f", dino_image)
background = Background(0, EARTH - 10, size_track[0], 4, track_image)
#enemy = Sprite(size_scr[0] - 50, 0, 50, 50, RED)
#goal = Sprite(0, 0, 50, 50, GREEN)


which_window = "MENU"
game = True

while game:
    events = pygame.event.get()
    if which_window == "MENU":
        screen.fill(GREEN)

        play.draw(screen)
        exit.draw(screen)

        if play.active(events):
            which_window = "GAME"
        elif exit.active(events):
            game = False
        elif which_window == "GAME":
            screen.fill(WHITE)

    elif which_window == "GAME":
        screen.fill(WHITE)

        background.move()
        background.blit_bg(screen)
        hero.blit_hero(screen)
        hero.gravitation()
        hero.jump(events)
        hero.move_image()




    elif which_window == "WIN":
        pass
    elif which_window == "LOSE":
        pass



    for event in events:
        if event.type == pygame.QUIT:
            game = False


    clock.tick(60)
    pygame.display.flip()

pygame.quit()