import pygame
import os



size_cloud = (84, 101)
cloude_size = (84, 101)
cactus_1_size = (40, 71)
cactus_1_size = (68, 71)
cactus_1_size = (105, 71)
size_track = (2404, 28)
size_scr = (500, 500)
size_hero = (88, 94)

EARTH = 400
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)


abs_path = os.path.join(os.path.abspath(__file__ + "/.."), "image")

cloud_image = pygame.image.load(os.path.join(abs_path, "Cloud.png"))
dino_image = [
pygame.image.load(os.path.join(abs_path, "DinoJump.png")),
pygame.image.load(os.path.join(abs_path, "DinoRun1.png")),
pygame.image.load(os.path.join(abs_path, "DinoRun2.png"))
]
cactus_1_image = pygame.image.load(os.path.join(abs_path, "SmallCactus1.png"))
cactus_2_image = pygame.image.load(os.path.join(abs_path, "SmallCactus2.png"))
cactus_3_image = pygame.image.load(os.path.join(abs_path, "SmallCactus3.png"))
track_image = pygame.image.load(os.path.join(abs_path, "Track.png"))



