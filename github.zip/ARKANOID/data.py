import pygame
import os
import random

pygame.init()


size_button = (160, 60)
size_scr = (500, 500)
size_board = (150, 34)
size_block = (50, 40)


EARTH = 400
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
BLOCK_COLORS = (None,GREEN, BLUE, RED)


abs_path = os.path.join(os.path.abspath(__file__ + "/.."), "image")

maps = {

    "lvl1":[
        "11111111",
        "11100111",
        "11111111"
    ]


}

#cloud_image = pygame.image.load(os.path.join(abs_path, "Cloud.png"))