from data import *

EARTH = 400

pygame.init()

class Label(pygame.font.Font):
    def __init__(self, size, font, colors, text):
        super().__init__(font, size)
        self.colors = colors
        self.text = text
        self.d_text = self.render(text, True, colors[0])

    def blit_text(self, x, y, screen):
        screen.blit(self.d_text, (x, y))

class Button(pygame.Rect):
    def __init__(self, x, y, width, heigth, colors, label):
        super().__init__(x, y, width, heigth)
        self.colors = colors
        self.label = label
        self.index = 0
        self.select = False

    def draw(self, screen):
        pygame.draw.rect(screen, self.colors[self.index], self)
        self.label.blit_text(
            self.centerx - self.label.size(self.label.text)[0] // 2,
            self.centery - self.label.size(self.label.text)[1] //2,
            screen
        )
    def active(self, events):
        if self.collidepoint(pygame.mouse.get_pos()):
            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                        print(1)
                        self.index = 2
                        self.select = True
                        return True
                if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    self.index = 0
                    self.select = False

                if not self.select:
                    self.index = 1
        else:
                self.index = 0

        return False



class Sprite(pygame.Rect):
    def __init__(self, x, y, width, heigth, color, image):
        super().__init__(x, y, width, heigth)
        self.color = color
        self.image = image
        

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self)

    def blit_sprite(self, screen):
        screen.blit(self.image, (self.x, self.y))

    def collide(self, rect):
        if self.collide(rect):
            return True
        return False

class Board(Sprite):
    def __init__(self, x, y, width, heigth, color, image, speed):
        super().__init__(x, y, width, heigth, color, image)
        self.speed = speed
        self.move = {"left" : False, "right" : False}


    def move_board(self):
        if self.move["left"] and self.x > 0:
            self.x -= self.speed
        elif self.move["right"] and self.right < size_scr[0]:
            self.x += self.speed


class Ball():
    def __init__(self, x, y, radius, color, image, step):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.image = image
        self.step = step
        self.step_x = 0
        self.step_y = self.step

    def draw(self, image):
        pygame.draw.circle(screen, self.color, (self.x, self.y,), self.radius)

    def blit(self, screen):
        screen.blit(self.image, (self.x, self.y))

    def move(self):
        self.x += self.step_x
        self.y += self.step_y

    def collide(self, board, blocks):
        self.collide_board(board)
        self.collide_barrier()
        self.collide_block(blocks)


    def collide_board(self, board):
        if board.collidepoint(self.x, self.y + self.radius):
            if board.move["left"]:
                self.step_x = - random.uniform(self.step / 5, self.step)
                self.step_y = (self.step ** 2 - self.step_x ** 2) ** 0.5
                cof = (self.step_x ** 2 + self.step_y ** 2) ** 0.5 / self.step
                self.step_x = self.step_x / cof
                self.step_y = self.step_y / cof
            elif board.move["right"]:
                self.step_x = random.uniform(self.step / 5, self.step)
                self.step_y = (self.step ** 2 - self.step_x ** 2) ** 0.5
                cof = (self.step_x ** 2 + self.step_y ** 2) ** 0.5 / self.step
                self.step_x = self.step_x / cof
                self.step_y = self.step_y / cof

            self.step_y *= -1

    def collide_barrier(self):
        if self.x - self.radius < 0 or self.x + self.radius > size_scr[0]:
            self.step_x *= -1
        elif self.y - self.radius < 0:
            self.step_y *= -1
            
    def collide_block(self, blocks):
        for block in blocks:
            if block.collidepoint(self.x, self.y + self.radius) or block.collidepoint(self.x, self.y - self.radius):
                self.step_y *= -1
                blocks.remove(block)
            elif block.collidepoint(self.x - self.radius, self.y) or block.collidepoint(self.x + self.radius, self.y):
                self.step_x *= -1
                blocks.remove(block)
            #toplest
            elif block.collidepoint(self.x + self.radius / 1.4, self.y + self.radius / 1.4):
                self.step_x = abs(self.step_y) * -1
                self.step_y = abs(self.step_x) * -1
                blocks.remove(block)
            #topright
            elif block.collidepoint(self.x + self.radius / 1.4, self.y + self.radius / 1.4):
                self.step_x = abs(self.step_y) * -1
                self.step_y = abs(self.step_x) * -1
                blocks.remove(block)
            elif block.collidepoint(self.x + self.radius / 1.4, self.y + self.radius / 1.4):
                self.step_x = abs(self.step_y) * -1
                self.step_y = abs(self.step_x) * -1
                blocks.remove(block)
            #bottonleft
            elif block.collidepoint(self.x + self.radius / 1.4, self.y - self.radius / 1.4):
                self.step_x = abs(self.step_y) * -1
                self.step_y = abs(self.step_x) * -1
                blocks.remove(block)
            #bottomright
            elif block.collidepoint(self.x + self.radius / 1.4, self.y - self.radius / 1.4):
                self.step_x = abs(self.step_y) * -1
                self.step_y = abs(self.step_x) * -1
                blocks.remove(block)
            else:
                pass
            
class Block(Sprite):
    def __init__(self, x, y, width, height, color, image, hp):
        super().__init__(x, y, width, height, color, image)
        self.hp = hp

def create_block(map_list):
    tmp_list = list()
    x, y = 10, 10
    for line in map_list:
        for char in line:
            if char == "1":
                tmp_list.append(Block(x, y, size_block[0], size_block[1], BLOCK_COLORS[int(char)], None, int(char)))
            elif char == "2":
                tmp_list.append(Block(x, y, size_block[0], size_block[1], BLOCK_COLORS[int(char)], None, int(char)))
            elif char == "3":
                tmp_list.append(Block(x, y, size_block[0], size_block[1], BLOCK_COLORS[int(char)], None, int(char)))
            x += size_block[0] + 10
        y += size_block[1] + 10
        x = 10

    return tmp_list

screen = pygame.display.set_mode(size_scr)
clock = pygame.time.Clock()

game = True

size_button = (150, 50)

play_label = Label(40, None, ((0, 0, 0), (157, 255, 122), (122, 255, 231)), "START")
exit_label = Label(40, None, ((0, 0, 0), (157, 255, 122), (122, 255, 231)), "EXIT")
button = Button(
    size_scr[0] // 2 - size_button[0] // 2, # - x
    size_scr[1] // 2 - size_button[1] // 2 - 40, # - y
    size_button[0],
    size_button[1],
    ((0, 255, 0, ), (0, 255, 255), (255, 255, 0)),
    play_label
)
play = Button(
    size_scr[0] // 2 - size_button[0] // 2,
    size_scr[1] // 2 - size_button[1] // 2 - 40, 
    size_button[0],
    size_button[1],
    ((24, 210, 134), (24, 180, 96), (238, 154, 10)),
    play_label
)

exit = Button(
    size_scr[0] // 2 - size_button[0] // 2,
    size_scr[1] // 2 - size_button[1] // 2,
    size_button[0],
    size_button[1],
    ((0, 255, 0, ), (0, 255, 255), (255, 255, 0)),
    exit_label
)
board = Board(size_scr[0] // 2 - size_board[0] // 2,
              size_scr[1] - size_board[1] - 10,
              size_board[0],
              size_board[1],
              "#FF0000",
              None,
              5)

ball = Ball(size_scr[0] // 2, size_scr[1] // 2, 5, BLUE, None, 5)
block_list = create_block(maps["lvl1"])






#goal = Sprite(0, 0, 50, 50, GREEN)


which_window = "MENU"
game = True

while game:
    events = pygame.event.get()
    if which_window == "MENU":
        screen.fill(GREEN)
        

        play.draw(screen)
        exit.draw(screen)

        if play.active(events):
            which_window = "GAME"
        elif exit.active(events):
            game = False
    elif which_window == "GAME":
        screen.fill(WHITE)

        board.move_board()
        board.draw(screen)

        ball.move()
        ball.draw(screen)
        ball.collide(board, block_list)

        for block in block_list:
            block.draw(screen)

        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    board.move["left"] = True
                if event.key == pygame.K_d:
                    board.move["right"] = True
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    board.move["left"] = False
                if event.key == pygame.K_d:
                    board.move["right"] = False



    elif which_window == "WIN":
        pass
    elif which_window == "LOSE":
        pass



    for event in events:
        if event.type == pygame.QUIT:
            game = False


    clock.tick(60)
    pygame.display.flip()

pygame.quit()