import json
import os
import random
import string
from datetime import datetime, timedelta
from aiogram import Router
from aiogram.filters import Command, CommandStart
from aiogram.types import Message

router = Router()

WEB = 'optima.college'
USERS_DB = '/home/bot/users.json'
CODES_DB = '/home/bot/codes.json'


def _load(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    with open(path, 'r', encoding='utf-8') as f:
        try:
            return json.load(f)
        except Exception:
            return {}


def _save(path: str, data: dict):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def gen_code(length: int = 6) -> str:
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))


def create_and_save_code(owner_id: int) -> dict:
    now = datetime.now()
    code = {
        "id": gen_code(),
        "owner_id": str(owner_id),
        "session_active": "no",
        "start_time": now.isoformat(timespec='seconds'),
        "end_time": (now + timedelta(hours=24)).isoformat(timespec='seconds'),
        "auth": "no",
        "attempts": 0,
    }
    codes = _load(CODES_DB)
    codes = {k: v for k, v in codes.items() if v.get('owner_id') != str(owner_id)}
    codes[code['id']] = code
    _save(CODES_DB, codes)
    return code


async def send_code(message: Message, code: dict):
    end_dt = datetime.fromisoformat(code['end_time'])
    end_str = end_dt.strftime('%H:%M %d.%m.%Y')
    await message.answer(
        f"⚠️ <b>Увага! Авторизація на сайті {WEB} </b> ⚠️\n\n"
        f"👉 Код: <code>{code['id']}</code>\n\n"
        f"⏳ Діє до: {end_str}\n"
        f"🔁 Після 3 невдалих спроб код згорає.",
        parse_mode="HTML"
    )


@router.message(CommandStart())
async def cmd_start(message: Message):
    uid = str(message.from_user.id)
    users = _load(USERS_DB)

    if uid not in users:
        users[uid] = {
            "id": uid,
            "username": message.from_user.username or "",
            "full_name": message.from_user.full_name or "",
            "web_auth": "no",
            "registered_at": datetime.now().isoformat(timespec='seconds'),
        }
        _save(USERS_DB, users)
        await message.answer("👋 Привіт! Тебе зареєстровано.")

    else:
        await message.answer("👋 З поверненням!")

    code = create_and_save_code(int(uid))
    await send_code(message, code)


@router.message(Command("code"))
async def cmd_code(message: Message):
    uid = str(message.from_user.id)
    users = _load(USERS_DB)

    if uid not in users:
        await message.answer("❌ Спочатку напиши /start.")
        return

    code = create_and_save_code(int(uid))
    await send_code(message, code)
