import re
from aiogram import Bot, F, Router
from aiogram.filters import Command
from aiogram.types import Message
from modules.logs import get_id_by_username

router = Router()

KICK_TEXT_RE = re.compile(r"^(викинути|кік)\s*(.*)", re.IGNORECASE)


def is_admin(member_status: str) -> bool:
    return member_status in ("administrator", "creator")


def clean_arg(value: str) -> str:
    return re.sub(r"[,.\s]+$", "", value).strip()


async def resolve_user_id(bot: Bot, chat_id: int, value: str) -> int | None:
    value = clean_arg(value)

    if re.fullmatch(r"-?\d+", value):
        return int(value)

    username = value.lstrip("@")

    try:
        member = await bot.get_chat_member(chat_id, f"@{username}")
        return member.user.id
    except Exception:
        pass

    try:
        chat = await bot.get_chat(f"@{username}")
        return chat.id
    except Exception:
        pass

    return get_id_by_username(username)


async def _do_kick(message: Message, bot: Bot, raw_arg: str | None):
    caller = await bot.get_chat_member(message.chat.id, message.from_user.id)
    if not is_admin(caller.status):
        await message.reply("❌ Ти не адмін.")
        return

    target_id: int | None = None
    target_name: str = ""

    if message.reply_to_message:
        target_id = message.reply_to_message.from_user.id
        target_name = (
            message.reply_to_message.from_user.username
            or message.reply_to_message.from_user.full_name
        )
    elif raw_arg:
        cleaned = clean_arg(raw_arg)
        target_id = await resolve_user_id(bot, message.chat.id, cleaned)
        if target_id is None:
            await message.reply(
                "❌ Не вдалося знайти користувача.\n"
                "💡 Використовуй ID або реплай на його повідомлення."
            )
            return
        target_name = cleaned.lstrip("@")
    else:
        await message.reply(
            "ℹ️ Використання:\n"
            "<code>/kick @username</code> | <code>/kick 123456789</code>\n"
            "<code>кік @username</code> | реплай на повідомлення.",
            parse_mode="HTML",
        )
        return

    if target_id == message.from_user.id:
        await message.reply("😐 Себе не кікаєш.")
        return

    try:
        target_member = await bot.get_chat_member(message.chat.id, target_id)
        if is_admin(target_member.status):
            await message.reply("❌ Не можна кікнути адміна.")
            return
    except Exception:
        pass

    try:
        await bot.ban_chat_member(message.chat.id, target_id)
        await bot.unban_chat_member(message.chat.id, target_id, only_if_banned=True)
        await message.reply(
            f"👢 <b>{target_name}</b> (<code>{target_id}</code>) кікнутий.",
            parse_mode="HTML",
        )
    except Exception as e:
        await message.reply(f"❌ Помилка при кіку: {e}")


@router.message(Command("kick"))
async def cmd_kick(message: Message, bot: Bot):
    args = message.text.split(maxsplit=1)
    raw_arg = args[1] if len(args) > 1 else None
    await _do_kick(message, bot, raw_arg)


@router.message(F.text.regexp(KICK_TEXT_RE))
async def text_kick(message: Message, bot: Bot):
    m = KICK_TEXT_RE.match(message.text)
    raw_arg = m.group(2).strip() or None
    await _do_kick(message, bot, raw_arg)
