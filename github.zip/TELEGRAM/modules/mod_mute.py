import re
from datetime import timedelta
from aiogram import Bot, F, Router
from aiogram.filters import Command
from aiogram.types import ChatPermissions, Message
from modules.logs import get_id_by_username

router = Router()


MUTE_TEXT_RE = re.compile(r"^(мут|mute)\s*(.*)", re.IGNORECASE)

TIME_RE = re.compile(
    r"(\d+)\s*(д|d|г|h|х|m|с|s)",
    re.IGNORECASE
)


def is_admin(member_status: str) -> bool:
    return member_status in ("administrator", "creator")


def clean_arg(value: str) -> str:
    return re.sub(r"[,.\s]+$", "", value).strip()


def parse_duration(text: str) -> tuple[int | None, str]:
    m = TIME_RE.search(text)
    if not m:
        return None, text.strip()

    amount = int(m.group(1))
    unit = m.group(2).lower()

    multipliers = {
        "д": 86400, "d": 86400,
        "г": 3600,  "h": 3600,
        "х": 60,    "m": 60,
        "с": 1,     "s": 1,
    }
    seconds = amount * multipliers[unit]

    remainder = (text[:m.start()] + text[m.end():]).strip()
    return seconds, remainder


def fmt_duration(seconds: int) -> str:
    if seconds >= 86400 and seconds % 86400 == 0:
        return f"{seconds // 86400}д"
    if seconds >= 3600 and seconds % 3600 == 0:
        return f"{seconds // 3600}г"
    if seconds >= 60 and seconds % 60 == 0:
        return f"{seconds // 60}хв"
    return f"{seconds}с"


async def resolve_user_id(bot: Bot, chat_id: int, value: str) -> int | None:
    value = clean_arg(value)
    if not value:
        return None

    if re.fullmatch(r"-?\d+", value):
        return int(value)

    username = value.lstrip("@")

    try:
        member = await bot.get_chat_member(chat_id, f"@{username}")
        return member.user.id
    except Exception:
        pass

    try:
        chat = await bot.get_chat(f"@{username}")
        return chat.id
    except Exception:
        pass

    return get_id_by_username(username)


async def _do_mute(message: Message, bot: Bot, raw_arg: str | None):
    caller = await bot.get_chat_member(message.chat.id, message.from_user.id)
    if not is_admin(caller.status):
        await message.reply("❌ Ти не адмін.")
        return

    target_id: int | None = None
    target_name: str = ""
    duration_sec: int | None = None

    if message.reply_to_message:
        target_id = message.reply_to_message.from_user.id
        target_name = (
            message.reply_to_message.from_user.username
            or message.reply_to_message.from_user.full_name
        )
        if raw_arg:
            duration_sec, _ = parse_duration(raw_arg)
    elif raw_arg:
        duration_sec, remainder = parse_duration(raw_arg)
        remainder = clean_arg(remainder)
        if remainder:
            target_id = await resolve_user_id(bot, message.chat.id, remainder)
            if target_id is None:
                await message.reply(
                    "❌ Не вдалося знайти користувача.\n"
                    "💡 Використовуй ID або реплай на його повідомлення."
                )
                return
            target_name = remainder.lstrip("@")
        else:
            await message.reply(
                "ℹ️ Використання:\n"
                "<code>/mute @username 1д</code> | реплай + <code>мут 1г</code>\n"
                "Без зазначення часу = перманентний мут.",
                parse_mode="HTML",
            )
            return
    else:
        await message.reply(
            "ℹ️ Використання:\n"
            "<code>/mute @username 1д</code> | реплай + <code>мут 1г</code>\n"
            "Без зазначення часу = перманентний мут.",
            parse_mode="HTML",
        )
        return

    if target_id == message.from_user.id:
        await message.reply("😐 Себе не мутиш.")
        return

    try:
        target_member = await bot.get_chat_member(message.chat.id, target_id)
        if is_admin(target_member.status):
            await message.reply("❌ Не можна замутити адміна.")
            return
    except Exception:
        pass

    no_permissions = ChatPermissions(
        can_send_messages=False,
        can_send_media_messages=False,
        can_send_polls=False,
        can_send_other_messages=False,
    )

    try:
        if duration_sec:
            until = message.date + timedelta(seconds=duration_sec)
            await bot.restrict_chat_member(
                message.chat.id, target_id,
                permissions=no_permissions,
                until_date=until,
            )
            label = fmt_duration(duration_sec)
            await message.reply(
                f"🔇 <b>{target_name}</b> (<code>{target_id}</code>) замучений на {label}.",
                parse_mode="HTML",
            )
        else:
            await bot.restrict_chat_member(
                message.chat.id, target_id,
                permissions=no_permissions,
            )
            await message.reply(
                f"🔇 <b>{target_name}</b> (<code>{target_id}</code>) замучений назавжди.",
                parse_mode="HTML",
            )
    except Exception as e:
        await message.reply(f"❌ Помилка при муті: {e}")


@router.message(Command("mute"))
async def cmd_mute(message: Message, bot: Bot):
    args = message.text.split(maxsplit=1)
    raw_arg = args[1] if len(args) > 1 else None
    await _do_mute(message, bot, raw_arg)


@router.message(F.text.regexp(MUTE_TEXT_RE))
async def text_mute(message: Message, bot: Bot):
    m = MUTE_TEXT_RE.match(message.text)
    raw_arg = m.group(2).strip() or None
    await _do_mute(message, bot, raw_arg)
