TELEGRAM_TOKEN = "тут ваш товар від бота телеграм"
GROQ_TOKEN = "Тут ваш токер від ШІ (Groq.com)"
CHAT_ID = "чат айді"

USERS_DB = '/home/bot/'
CODES_DB = '/home/bot/'
MESSAGES_LOG = '/home/bot/'

WEB_ROOT = '/home/bot/'
SECRETS_ROOT = '/home/bot/'
