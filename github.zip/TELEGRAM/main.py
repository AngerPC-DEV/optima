#для OPTIMA
#{
import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
#} це сам модуль телеграм AioGram
from modules.mod_ban import router as ban_router
from modules.mod_unban import router as unban_router
from modules.mod_kick import router as kick_router
from modules.mod_mute import router as mute_router
from modules.mod_unmute import router as unmute_router
from modules.mod_start import router as start_router
from settings import TELEGRAM_TOKEN

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s"
)

#це регістрація хєндлеров як в Python-telegram-bot (PTB) я використовую цю тому що цей модуль дуже зручний є роутер для розливання на частини
async def main():
    bot = Bot(token=TELEGRAM_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()

    dp.message.middleware(UserLoggerMiddleware())

    dp.include_routers(
        start_router,
        ban_router,
        unban_router,
        kick_router,
        mute_router,
        unmute_router,
        chat_log_router
    )

    await dp.start_polling(bot, allowed_updates=["message", "chat_member"])



if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logging.info("Бот вимкнений")
