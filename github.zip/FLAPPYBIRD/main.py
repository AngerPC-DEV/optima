from data import *


pygame.init()

class Label(pygame.font.Font):
    def __init__(self, size, font, colors, text):
        super().__init__(font, size)
        self.colors = colors
        self.text = text
        self.d_text = self.render(text, True, colors[0])

    def blit_text(self, x, y, screen):
        screen.blit(self.d_text, (x, y))

class Button(pygame.Rect):
    def __init__(self, x, y, width, heigth, colors, label):
        super().__init__(x, y, width, heigth)
        self.colors = colors
        self.label = label
        self.index = 0
        self.select = False

    def draw(self, screen):
        pygame.draw.rect(screen, self.colors[self.index], self)
        pygame.draw.rect(screen, (0, 0, 0), self, width=2)
        
        self.label.blit_text(
            self.centerx - self.label.size(self.label.text)[0] // 2,
            self.centery - self.label.size(self.label.text)[1] // 2,
            screen
        )

    def active(self, events):
        if self.collidepoint(pygame.mouse.get_pos()):
            if not self.select:
                self.index = 1

            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    print(1)
                    self.index = 2
                    self.select = True
                    return True
                
                if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    self.select = False
                    self.index = 1 
        else:
            self.index = 0
            self.select = False

        return False



class Sprite(pygame.Rect):
    def __init__(self, x, y, width, heigth, color):
        super().__init__(x, y, width, heigth)
        self.color = color

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self)

class Hero(Sprite):
    def __init__(self, x, y, width, heigth, color, image):
        super().__init__(x, y, width, heigth, color)
        self.image_list = image
        self.image_count = 9
        self.jump_select = True
        self.jump_power_static = 20
        self.jump_power = self.jump_power_static
        self.gravitation_power = 3

    def jump(self, events):
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w and self.jump_select and self.top > 0:
                    self.jump_select = False
        if not self.jump_select:
            self.y -= self.jump_power
            self.jump_power -= 2
            if self.jump_power <= 0:
                self.jump_select = True
                self.jump_power = self.jump_power_static


    def gravitation(self):
            self.y += self.gravitation_power

    def blit_hero(self, screen):
        screen.blit(self.image, (self.x, self.y))


    def move_image(self):
        if not self.jump_select:
            self.image = self.image_list[0]
        else:
            if self.image_count == 19:
                self.image_count = 0
            self.image_count += 1
            if self.image_count  % 10 == 0:
                self.image = self.image_list[self.image_count // 10]


class Background():
    def __init__(self, x, y, width, speed, image):
        self.x1 = x
        self.x2 = self.x1 + width
        self.y = y
        self.width = width
        self.speed = speed
        self.image1 = image
        self.image2 = image

    def move(self):
        self.x1 -= self.speed
        self.x2 -= self.speed
        if self.x1 < -self.width:
            self.x1 = -self.width
        if self.x2 < -self.width:
            self.x2 = -self.width

    def blit_bg(self, screen):
        screen.blit(self.image1, (self.x1, self.y))
        screen.blit(self.image2, (self.x2, self.y))

class Cloud(pygame.Rect):
    def __init__(self, x, y, width, heigth, image, speed):
        super().__init__(x, y, width, heigth)
        self.image = image
        self.static_x = x
        self.speed = speed

    def move(self):
        self.x -= self.speed
        if self.right < 0:
            self.x  = self.static_x

    def blit_cloud(self, screen):
        screen.blit(self.image, (self.x, self.y))


class Tube(pygame.Rect):
    def __init__(self, x, y, width, heigth, image, speed,i):
        super().__init__(x, y, width, heigth)
        self.image1 = image[0]
        self.image2 = image[1]
        self.static_x = x
        self.speed = speed
        self.i = i

    def move(self):
        self.x -= self.speed
        if self.right < 0:
            self.x  = size_scr[0]
            self.y = random.randint(size_scr[1] // 2,  size_scr[1] - 50)


    def blit_tube(self, screen):
        screen.blit(self.image1, (self.x, self.y))
        screen.blit(self.image2, (self.x, self.y - self.height - 200))


screen = pygame.display.set_mode(size_scr)
clock = pygame.time.Clock()

game = True

size_button = (150, 50)

play_label = Label(40, None, ((0, 0, 0), (157, 255, 122), (122, 255, 231)), "START")
exit_label = Label(40, None, ((0, 0, 0), (157, 255, 122), (122, 255, 231)), "EXIT")

play = Button(
    size_scr[0] // 2 - size_button[0] // 2,
    size_scr[1] // 2 - size_button[1] // 2 - 40, 
    size_button[0],
    size_button[1],
    ((255, 0, 155), (255, 0, 55), (255, 0, 155)),
    play_label
)

exit = Button(
    size_scr[0] // 2 - size_button[0] // 2,
    size_scr[1] // 2 - size_button[1] // 2 +40,
    size_button[0],
    size_button[1],
    ((255, 0, 155 ), (255, 0, 55), (255, 0, 155)),
    exit_label
)
hero = Hero(30, size_hero[1] // 2, size_hero[0], size_hero[1], "#00a2ff", tubes_image)


cloud_list = []
cloud_list.append(Cloud(size_scr[0], random.randint(0, size_cloud[1]), size_cloud[0], size_cloud[1], cloud_image, 1))
cloud_list.append(Cloud(size_scr[0] + 200, random.randint(0, size_cloud[1]), size_cloud[1], size_cloud[0], cloud_image, 1))
cloud_list.append(Cloud(size_scr[0] + 400, random.randint(0, size_cloud[1]), size_cloud[1], size_cloud[0], cloud_image, 1))


tube_list = []
tube_list.append(Tube(size_scr[0], random.randint(size_scr[1] // 2,  size_scr[1] - 50), size_tube[0], size_tube[1], [tube_image1,tube_image2], 4,1))
tube_list.append(Tube(size_scr[0] + size_scr[0] // 3 + size_tube[0]//2, random.randint(size_scr[1] // 2,  size_scr[1] - 50), size_tube[0], size_tube[1], [tube_image1,tube_image2], 4,2))
tube_list.append(Tube(size_scr[0] + size_scr[0] // 3 * 2 + size_tube[0]//2*2, random.randint(size_scr[1] // 2,  size_scr[1] - 50), size_tube[0], size_tube[1], [tube_image1,tube_image2], 4,3))
#cloud_list.append(Cloud(size_scr[0] + 600, random.randint(0, size_cloud[1]), size_cloud[1], size_cloud[0], cloud_image, 1))
#enemy = Sprite(size_scr[0] - 50, 0, 50, 50, RED)
#goal = Sprite(0, 0, 50, 50, GREEN)
font_score = Label(40, None, ["purple", "", ""], "")


which_window = "MENU"
game = True
while game:
    events = pygame.event.get()
    if which_window == "MENU":
        screen.fill(PURPLE_LIGHT)
        

        play.draw(screen)
        exit.draw(screen)

        if play.active(events):
            which_window = "GAME"
        elif exit.active(events):
            game = False
    elif which_window == "GAME":
        screen.fill(WHITE)

        for cloud in cloud_list:
            cloud.move()
            cloud.blit_cloud(screen)

        for tube in tube_list:
            tube.move()
            tube.blit_tube(screen)        
            if hero.colliderect(tube.image1.get_rect(topleft=(tube.x,tube.y))) or hero.colliderect(tube.image2.get_rect(topleft=(tube.x,tube.y -tube.height- 200))):
                screen.blit(pygame.font.Font(None, 60).render("ПОТРАЧЕНО", True, "RED"), (150, 250))
                pygame.display.flip()
                time.sleep(2)
                which_window = "MENU"
                tube_list = []
                tube_list.append(Tube(size_scr[0], random.randint(size_scr[1] // 2,  size_scr[1] - 50), size_tube[0], size_tube[1], [tube_image1,tube_image2], 4,1))
                tube_list.append(Tube(size_scr[0] + size_scr[0] // 3 + size_tube[0]//2, random.randint(size_scr[1] // 2,  size_scr[1] - 50), size_tube[0], size_tube[1], [tube_image1,tube_image2], 4,2))
                tube_list.append(Tube(size_scr[0] + size_scr[0] // 3 * 2 + size_tube[0]//2*2, random.randint(size_scr[1] // 2,  size_scr[1] - 50), size_tube[0], size_tube[1], [tube_image1,tube_image2], 4,3))



        screen.blit(font_score.render(f"{round(pygame.time.get_ticks() / 1000)}", True, font_score.colors[0]), (size_scr[0] - 50, 10))
        hero.gravitation()
        hero.jump(events)
        hero.move_image()
        hero.blit_hero(screen)




    elif which_window == "WIN":
        pass
    elif which_window == "LOSE":
        pass



    for event in events:
        if event.type == pygame.QUIT:
            game = False

    clock.tick(60)
    pygame.display.flip()

pygame.quit()