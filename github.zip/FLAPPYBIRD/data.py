import pygame
import os
import random
import time

pygame.init()

size_cloud = (84, 101)
size_tube = (80, 600)
size_track = (2404, 28)
size_scr = (600, 500)
size_hero = (42, 25)


WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
PURPLE_LIGHT = (215, 11, 201)


abs_path = os.path.join(os.path.abspath(__file__ + "/.."), "image")

cloud_image = pygame.image.load(os.path.join(abs_path, "Cloud.png"))
tubes_image = [
pygame.image.load(os.path.join(abs_path, "bird1.png")),
pygame.image.load(os.path.join(abs_path, "bird2.png"))

]
tube_image1 = pygame.image.load(os.path.join(abs_path, "tube.png"))
tube_image2 = pygame.transform.flip(   pygame.image.load(os.path.join(abs_path, "tube.png")), False, True)
#track_image = pygame.image.load(os.path.join(abs_path, "Track.png"))



